export default {
    url: 'mongodb://35.166.33.218:28018/velobike'
}