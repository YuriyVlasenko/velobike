export default {
    url: 'mongodb://34.215.59.141:28018/velobike'
}