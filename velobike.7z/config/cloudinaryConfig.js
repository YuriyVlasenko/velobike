export default {
    cloudName: 'velobike',
    APIKey: '112284814369518',
    APISecret: '77SVRTMuk0PsbQr3HdV6bTf4Lq0',
    environmentVariable: 'CLOUDINARY_URL=cloudinary://112284814369518:77SVRTMuk0PsbQr3HdV6bTf4Lq0@velobike',
    baseDeliveryUrl: 'http://res.cloudinary.com/velobike',
    APIBaseURL: 'https://api.cloudinary.com/v1_1/velobike/image/upload'    
}