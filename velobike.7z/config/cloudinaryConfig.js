
/*
export default {
    cloudName: 'velobike',
    APIKey: '112284814369518',
    APISecret: '77SVRTMuk0PsbQr3HdV6bTf4Lq0',
    environmentVariable: 'CLOUDINARY_URL=cloudinary://112284814369518:77SVRTMuk0PsbQr3HdV6bTf4Lq0@velobike',
    baseDeliveryUrl: 'http://res.cloudinary.com/velobike',
    APIBaseURL: 'https://api.cloudinary.com/v1_1/velobike/image/upload'    
}
*/
//cloudinaryYV@gmail.com
export default {
    cloudName: 'dludxnhnb',
    APIKey: '252127857363337',
    APISecret: 'Szj8obhkZSlWMzhuXHGxxM3M2Vs',
    environmentVariable: 'CLOUDINARY_URL=cloudinary://252127857363337:Szj8obhkZSlWMzhuXHGxxM3M2Vs@dludxnhnb',
    baseDeliveryUrl: 'http://res.cloudinary.com/dludxnhnb',
    APIBaseURL: 'https://api.cloudinary.com/v1_1/dludxnhnb/image/upload'    
}

//cloudinaryYV1@gmail.com
/*
export default {
    cloudName: 'dryblwq7f',
    APIKey: '946249371874378',
    APISecret: 'IvhGKFyHlz-ujtkV4x6ZNgTwvhY',
    environmentVariable: 'CLOUDINARY_URL=cloudinary://946249371874378:IvhGKFyHlz-ujtkV4x6ZNgTwvhY@dryblwq7f',
    baseDeliveryUrl: 'http://res.cloudinary.com/dryblwq7f',
    APIBaseURL: 'https://api.cloudinary.com/v1_1/dryblwq7f/image/upload'    
}*/


//cloudinaryYV2@gmail.com
/*
export default {
    cloudName: 'dy9ohaciy',
    APIKey: '424768927359216',
    APISecret: 'MIwyTDVBYYudP5om-jgTxfJYfZI',
    environmentVariable: 'CLOUDINARY_URL=cloudinary://424768927359216:MIwyTDVBYYudP5om-jgTxfJYfZI@dy9ohaciy',
    baseDeliveryUrl: 'http://res.cloudinary.com/dy9ohaciy',
    APIBaseURL: 'https://api.cloudinary.com/v1_1/dy9ohaciy/image/upload'    
}*/

//cloudinaryyv3@gmail.com
/*
export default {
    cloudName: 'dk6bzcdpi',
    APIKey: '836951167467934',
    APISecret: 'nwaxrKsOLrOZEEXRFSv1VTQJHcE',
    environmentVariable: 'CLOUDINARY_URL=cloudinary://836951167467934:nwaxrKsOLrOZEEXRFSv1VTQJHcE@dk6bzcdpi',
    baseDeliveryUrl: 'http://res.cloudinary.com/dk6bzcdpi',
    APIBaseURL: 'https://api.cloudinary.com/v1_1/dk6bzcdpi/image/upload'    
}*/