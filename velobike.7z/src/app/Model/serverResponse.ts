interface IServerResponse {
    isOk: boolean;
    data: any;
    error: any;
}

export default IServerResponse;