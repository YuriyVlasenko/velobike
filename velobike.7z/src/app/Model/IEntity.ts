interface IEntity{
    id: string,
    displayName: string
} 

export default IEntity; 