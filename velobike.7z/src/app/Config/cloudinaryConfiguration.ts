/*
export default {
    cloudName: 'velobike',
    uploadPreset: 'mwgx6hsr'
}*/

//cloudinaryYV@gmail.com
export default {
    cloudName: 'dludxnhnb',
    uploadPreset: 'oeml6end'
}

//cloudinaryYV1@gmail.com
/*
export default {
    cloudName: 'dryblwq7f',
    uploadPreset: 'qjmvzmhd'
}
*/

//cloudinaryYV2@gmail.com
/*
export default {
    cloudName: 'dy9ohaciy',
    uploadPreset: 'cghk2mha'
}
*/

//cloudinaryYV3@gmail.com
/*
export default {
    cloudName: 'dk6bzcdpi',
    uploadPreset: 'tg7egip2'
}
*/