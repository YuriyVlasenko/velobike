export default {
    cloudName: 'velobike',
    uploadPreset: 'mwgx6hsr'
}